<?php
session_start();
include("config.php");
include("function.php");

if (isset($_SESSION["loggedin"])) {
    header("location: welcome.php");
    exit;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];
    $recaptcha_response = $_POST['g-recaptcha-response'];
    $confirm_passs = $_POST['confirm-password'];





    if (!verifyRecaptcha($recaptcha_response)) {
        $_SESSION['message'] = "Invalid reCAPTCHA. Please try again.";
        header("location: register.php");
        exit();
    }
    $sql = "SELECT id FROM users WHERE username = ?";
    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "s", $param_username);
        $param_username = $username;
        if (mysqli_stmt_execute(statement: $stmt)) {
            mysqli_stmt_store_result($stmt);
            if (mysqli_stmt_num_rows($stmt) == 1) {
                $_SESSION['message'] = "This username is already taken.";
            } else {

                if ($password === $confirm_passs) {
                    $sql = "INSERT INTO users (username, password) VALUES (?, ?)";
                    if ($stmt = mysqli_prepare($conn, $sql)) {
                        mysqli_stmt_bind_param($stmt, "ss", $param_username, $param_password);
                        $param_username = $username;
                        $param_password = password_hash($password, PASSWORD_DEFAULT);
                        if (mysqli_stmt_execute($stmt)) {
                            $_SESSION['message'] = "Registration successful. You can now log in.";
                            header("location: login.php");
                            exit();
                        } else {
                            $_SESSION['message'] = "Something went wrong. Please try again later.";
                        }
                    }
                }
                else{
                    $_SESSION['message'] = "Password doesn't match.";
                }


            }
        } else {
            $_SESSION['message'] = "Oops! Something went wrong. Please try again later.";
        }
        mysqli_stmt_close($stmt);
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="flex justify-center items-center align-middle">
    <div class="mt-[100px] border shadow-lg p-24">
        <h2 class="text-2xl font-bold text-center">Sign up</h2>
        <p class="text-red-600 text-center"><?php echo isset($_SESSION['message']) ? $_SESSION['message'] : '';
        unset($_SESSION['message']); ?></p>
        <form class="flex flex-col gap-4" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="flex flex-col">
                <label class="text-slate-500 text-sm">Username</label>
                <input class="border p-4" type="text" name="username" required>
            </div>
            <div class="flex flex-col">
                <label class="text-slate-500 text-sm">Password</label>
                <input class="border p-4" type="password" name="password" required>
            </div>


            <div class="flex flex-col">
                <label class="text-slate-500 text-sm">Confirm Password</label>
                <input class="border p-4" type="password" name="confirm-password" required>
            </div>

            <div class="g-recaptcha" data-sitekey="<?php echo $recaptcha_site_key; ?>"></div>
            <div class="m-auto duration-300 hover:bg-slate-200 rounded-lg">
                <input class="cursor-pointer border p-4 w-[150px]" type="submit" value="Signup">
            </div>
            <p>Already have an account? <a href="login.php">Login</a>.</p>
        </form>
    </div>

</body>


</html>