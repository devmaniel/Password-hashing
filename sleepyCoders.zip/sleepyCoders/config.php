<?php 


$conn = mysqli_connect('localhost', 'root', '', 'login_system2');

if($conn === false){
    die("ERROR: could not connect" . mysqli_connect_error());
}


$recaptcha_site_key = '6LdNzUoqAAAAAK-nXUkU2cXhAGThYzrm4bujMUK9';
$recaptcha_secret_key= '6LdNzUoqAAAAAMaOfu9u90_rXC87p5mwqq6hRox4';

?>